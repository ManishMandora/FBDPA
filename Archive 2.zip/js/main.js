

//---------------------Input type File Setting------------------------------------------//

function setPath(f) {
	document.getElementById('mypath').value = f;
	//document.getElementById('mypath').value = "";
}


function browse() 
{  //alert("hello");
	document.getElementById('realFile').click();
}

